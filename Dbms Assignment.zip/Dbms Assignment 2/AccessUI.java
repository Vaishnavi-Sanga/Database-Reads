import javax.swing.*;
class AccessesUI extends JFrame
{
	JTextField t1,t2;
	JLabel l1,l2;
	JPanel p;
	
	public AccessesUI()
	{
		//setSize(450,450);
		//setLayout(null);
		//setVisible(true);
		createComponents();
		addComponents();
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	void createComponents()
	{
		t1 = new JTextField();
		t1.setBounds(200,30,150,30);
		
		t2 = new JTextField();
		t2.setBounds(200,100,150,30);
		
		
		l1 = new JLabel("Student ID :  ");
		l1.setBounds(50,30,150,30);
		
		l2 = new JLabel("Book ID :  ");
		l2.setBounds(50,100,150,30);
		
		
		p = new JPanel(null);
		p.setBounds(0,0,400,250);
	}
	
	void addComponents()
	{
		p.add(l1);
		p.add(t1);
		p.add(l2);
		p.add(t2);
		
		add(p);
	}
	
	/*public static void main(String a[])
	{
		new AccessesUI();
	}*/
}

