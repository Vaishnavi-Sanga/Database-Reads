import java.sql.Connection;
import java.sql.DriveManager;
import java.sql.*;

	public class connector {
		public static Connection getConnection() throws Exception
		
		{
			class.forName("oracle.jdbc.OracleDriver");
			Connection cn = DriveManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737304","vasavi");
			String query = "Insert into sailors (sid, sname, rating, age) values(?, ?, ?, ?)";
			PreparedStatement st = conn.prepareStatement(query);
			st.setString(1, s1);
			st.setString(2, name);
			st.setString(3, s2);
			st.setString(4, s3);
			int r = st.executeUpdate();
			if(r > 0){
				System.out.println("inserted successfully");
		}
	}