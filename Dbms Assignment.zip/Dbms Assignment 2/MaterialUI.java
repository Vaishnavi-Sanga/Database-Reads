import javax.swing.*;
class MaterialUI extends JFrame
{
	JTextField t1,t2,t3,t4;
	JComboBox<String> j1;
	JLabel l1,l2,l3,l4;
	JPanel p;
	
	public MaterialUI()
	{
	//	setSize(450,450);
	//	setLayout(null);
		//setVisible(true);
		createComponents();
		addComponents();
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	void createComponents()
	{
		//t1 = new JTextField();
		//t1.setBounds(200,30,150,30);
		String[] optionsToChoose = {"101", "201", "301", "401", "501"};
		j1 = new JComboBox<>(optionsToChoose);
        j1.setBounds(200, 30, 150, 30);
		
		t2 = new JTextField();
		t2.setBounds(200,80,150,30);
		
		t3 = new JTextField();
		t3.setBounds(200,140,150,30);
		
		t4 = new JTextField();
		t4.setBounds(200,200,150,30);
		
		l1 = new JLabel("Book ID :  ");
		l1.setBounds(50,30,150,30);
		
		l2 = new JLabel("Author ID :  ");
		l2.setBounds(50,80,150,30);
		
		l3 = new JLabel("Book Name :  ");
		l3.setBounds(50,140,150,30);
		
		l4 = new JLabel("Image :  ");
		l4.setBounds(50,200,150,30);
		
		p = new JPanel(null);
		p.setBounds(0,0,400,250);
	}
	
	void addComponents()
	{
		p.add(l1);
		p.add(j1);
		p.add(l2);
		p.add(t2);
		p.add(l3);
		p.add(t3);
		p.add(l4);
		p.add(t4);
		add(p);
	}
	
	/*public static void main(String a[])
	{
		new MaterialUI();
	}*/
}

